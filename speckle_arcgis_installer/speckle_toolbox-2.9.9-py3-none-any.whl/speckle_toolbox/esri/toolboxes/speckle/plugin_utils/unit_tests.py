
import arcpy
from arcpy._mp import ArcGISProject, Map, Layer as arcLayer

import json
import os

from arcpy._mp import ArcGISProject, Map, Layer as arcLayer
from arcpy.management import (CreateFeatureclass, MakeFeatureLayer,
                              AddFields, AlterField, DefineProjection )

import unittest 

